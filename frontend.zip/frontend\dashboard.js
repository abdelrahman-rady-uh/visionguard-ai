const raw = localStorage.getItem("analysisResult");
if (!raw) {
  window.location.href = "/";
}

const state = JSON.parse(raw || "{}");
const result = state.result || {};
let videoDuration = 0;

function clamp(v) {
  return Math.max(0, Math.min(100, Number(v || 0)));
}

function animateValue(element, start, end, duration) {
  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    const easeOut = progress < 0.5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
    const current = start + (end - start) * easeOut;
    element.textContent = current.toFixed(2) + "%";
    if (progress < 1) {
      requestAnimationFrame(step);
    }
  };
  requestAnimationFrame(step);
}

function addBar(label, value) {
  const wrap = document.getElementById("confidenceWrap");
  const node = document.createElement("div");
  node.className = "bar";
  const percentageSpan = document.createElement("span");
  percentageSpan.textContent = "0%";
  
  node.innerHTML = `
    <div class="bar-head"><span>${label}</span><span id="bar-${label}">0%</span></div>
    <div class="bar-track"><div class="bar-fill" style="width:${clamp(value)}%"></div></div>
  `;
  
  wrap.appendChild(node);
  
  const barPercentageEl = node.querySelector(`#bar-${label}`);
  setTimeout(() => {
    animateValue(barPercentageEl, 0, value, 1200);
  }, 100);
}

function addForensicDetail(label, value) {
  const wrap = document.getElementById("forensicsWrap");
  const node = document.createElement("div");
  node.className = "forensic-item";
  node.innerHTML = `
    <div class="forensic-label">${label}</div>
    <div class="forensic-value">${value}</div>
  `;
  wrap.appendChild(node);
}

function addSignal(label, value) {
  const wrap = document.getElementById("signalWrap");
  const node = document.createElement("div");
  node.className = "signal";
  node.innerHTML = `<label>${label}</label><strong>${value}</strong>`;
  wrap.appendChild(node);
  
  const index = wrap.children.length - 1;
  node.style.animationDelay = `${index * 0.1}s`;
}

function formatTime(seconds) {
  const s = Math.max(0, Number(seconds || 0));
  const mm = Math.floor(s / 60).toString().padStart(2, "0");
  const ss = Math.floor(s % 60).toString().padStart(2, "0");
  return `${mm}:${ss}`;
}

function addTimelineItem(item) {
  const wrap = document.getElementById("timelineWrap");
  const node = document.createElement("div");
  node.className = "timeline-item";
  node.innerHTML = `
    <div class="timeline-time">Shot ${item.shot} | ${formatTime(item.start_time)}-${formatTime(item.end_time)}</div>
    <div class="timeline-event">${item.event}</div>
    <div class="timeline-conf">Caption confidence: ${clamp(item.confidence).toFixed(2)}%</div>
  `;
  wrap.appendChild(node);
  
  const index = wrap.children.length - 1;
  node.style.animationDelay = `${index * 0.08}s`;
  
  // Click to jump to this timestamp
  node.addEventListener("click", () => {
    const video = document.getElementById("videoPreview");
    video.currentTime = item.start_time;
    video.play();
  });
}

function setupTimelineScrubber() {
  const video = document.getElementById("videoPreview");
  const timelineBar = document.getElementById("timelineBar");
  const eventMarkers = document.getElementById("eventMarkers");
  const timelineScrubber = document.querySelector(".timeline-scrubber");
  
  const shotEvents = result.shot_events || [];
  const metadata = result.metadata || {};
  videoDuration = metadata.duration || 0;
  
  // Create event markers
  shotEvents.forEach((event) => {
    if (videoDuration > 0) {
      const marker = document.createElement("div");
      marker.className = "event-marker";
      const percent = (event.start_time / videoDuration) * 100;
      marker.style.left = percent + "%";
      marker.title = event.event;
      marker.addEventListener("click", (e) => {
        e.stopPropagation();
        video.currentTime = event.start_time;
        video.play();
      });
      eventMarkers.appendChild(marker);
    }
  });
  
  // Update timeline bar on video progress
  video.addEventListener("timeupdate", () => {
    if (videoDuration > 0) {
      const percent = (video.currentTime / videoDuration) * 100;
      timelineBar.style.width = percent + "%";
    }
  });
  
  // Click on scrubber to seek
  timelineScrubber.addEventListener("click", (e) => {
    const rect = timelineScrubber.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    video.currentTime = percent * videoDuration;
  });
}

function exportAsJSON() {
  const exportData = {
    metadata: state,
    analysis: result,
    exportedAt: new Date().toISOString(),
  };
  
  // Send to backend for proper JSON export
  fetch("/api/export/json", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ data: exportData })
  })
  .then(response => response.blob())
  .then(blob => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `analysis_${new Date().getTime()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  })
  .catch(err => alert("Export failed: " + err.message));
}

function exportAsPDF() {
  const exportData = {
    metadata: state,
    analysis: result,
    exportedAt: new Date().toISOString(),
  };
  
  // Send to backend for proper PDF export
  fetch("/api/export/pdf", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ data: exportData })
  })
  .then(response => {
    if (!response.ok) throw new Error("PDF export not available");
    return response.blob();
  })
  .then(blob => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `analysis_${new Date().getTime()}.pdf`;
    link.click();
    URL.revokeObjectURL(url);
  })
  .catch(err => {
    console.error(err);
    alert("PDF export not available. Exporting as text instead.");
    // Fallback to text export
    const content = `
VISIONGUARD AI - ANALYSIS REPORT
Generated: ${new Date().toISOString()}

VIDEO METADATA
File: ${state.fileName || 'Unknown'}
Size: ${state.fileSize ? (state.fileSize / (1024*1024)).toFixed(2) : 'N/A'} MB
SHA256: ${state.sha256 || 'N/A'}

AI DETECTION RESULTS
Status: ${result.ai_detection?.status || '-'}
Confidence: ${clamp(result.ai_detection?.confidence).toFixed(2)}%

FORENSIC SIGNALS
${
  Object.entries(result.ai_detection?.signals || {})
    .map(([k, v]) => `${k.replaceAll('_', ' ')}: ${v}`)
    .join('\n')
}

TAMPERING ANALYSIS
Type: ${result.tampering?.tampering_type || '-'}
Confidence: ${clamp(result.tampering?.confidence).toFixed(2)}%

FACE DETECTION
Detected: ${result.face_detection?.faces_detected ? 'Yes' : 'No'}
Total Faces: ${result.face_detection?.total_faces || 0}
Alert: ${result.face_detection?.alert || '-'}

CAPTION
${result.caption?.caption || '-'}

EVENT TIMELINE
${
  (result.shot_events || [])
    .map(e => `Shot ${e.shot} [${formatTime(e.start_time)}-${formatTime(e.end_time)}]: ${e.event}`)
    .join('\n')
}
    `.trim();
    
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `analysis_${new Date().getTime()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  });
}

function setRiskBadge(aiConf, tamperConf, faceDetected) {
  const badge = document.getElementById("riskBadge");
  const risk = Math.max(clamp(aiConf), clamp(tamperConf)) + (faceDetected ? 8 : 0);
  badge.classList.remove("risk-low", "risk-mid", "risk-high");
  if (risk < 45) {
    badge.classList.add("risk-low");
    badge.textContent = "Overall Risk: Low";
  } else if (risk < 75) {
    badge.classList.add("risk-mid");
    badge.textContent = "Overall Risk: Medium";
  } else {
    badge.classList.add("risk-high");
    badge.textContent = "Overall Risk: High";
  }
}

document.getElementById("videoPreview").src = state.videoUrl || "";
document.getElementById("videoPreview").addEventListener('error', (e) => {
  console.error('Video loading error:', e);
  const videoElement = document.getElementById("videoPreview");
  // Fallback: Try to load from encrypted path if available
  if (state.result?.preview_path) {
    videoElement.innerHTML = '<p style="color: #red;">Video preview unavailable. Encrypted file stored securely.</p>';
  }
});
document.getElementById("videoPreview").addEventListener('loadstart', () => {
  console.log('Video loading started');
});
document.getElementById("videoPreview").addEventListener('canplay', () => {
  console.log('Video can play');
});

document.getElementById("captionText").textContent = result.caption?.caption || "-";
document.getElementById("aiStatus").textContent = `${result.ai_detection?.status || "-"} (${clamp(result.ai_detection?.confidence).toFixed(2)}%)`;
document.getElementById("tamperingText").textContent = `${result.tampering?.tampering_type || "-"} (${clamp(result.tampering?.confidence).toFixed(2)}%)`;
document.getElementById("faceText").textContent = result.face_detection?.faces_detected
  ? `Faces detected (${result.face_detection?.total_faces || 0})`
  : "No faces detected";
document.getElementById("privacyAlert").textContent = result.face_detection?.alert || "-";

addBar("Caption", clamp(result.caption?.confidence));
addBar("AI Detection", clamp(result.ai_detection?.confidence));
addBar("Tampering", clamp(result.tampering?.confidence));
addBar("Face Detection", clamp(result.face_detection?.confidence));

const signals = result.ai_detection?.signals || {};
Object.keys(signals).forEach((k) => addSignal(k.replaceAll("_", " "), signals[k]));

// Add forensic details
Object.entries(signals).forEach(([key, value]) => {
  addForensicDetail(key.replaceAll("_", " "), String(value));
});

const shotEvents = result.shot_events || [];
if (shotEvents.length) {
  shotEvents.forEach((s) => addTimelineItem(s));
} else {
  addTimelineItem({ shot: 1, start_time: 0, end_time: 0, event: "No shot events extracted.", confidence: 0 });
}

setRiskBadge(result.ai_detection?.confidence, result.tampering?.confidence, result.face_detection?.faces_detected);

if (result.preview_path) {
  const imgName = result.preview_path.split(/[\\/]/).pop();
  document.getElementById("blurPreview").src = `/results/${imgName}`;
}

// Setup event listeners
document.getElementById("exportJSON").addEventListener("click", exportAsJSON);
document.getElementById("exportPDF").addEventListener("click", exportAsPDF);
document.getElementById("fullScreen").addEventListener("click", () => {
  const video = document.getElementById("videoPreview");
  
  // Try different fullscreen APIs for browser compatibility
  if (video.requestFullscreen) {
    video.requestFullscreen();
  } else if (video.webkitRequestFullscreen) {
    video.webkitRequestFullscreen();
  } else if (video.mozRequestFullScreen) {
    video.mozRequestFullScreen();
  } else if (video.msRequestFullscreen) {
    video.msRequestFullscreen();
  } else {
    // Fallback: Try fullscreen on the parent container
    const container = video.parentElement;
    if (container.requestFullscreen) {
      container.requestFullscreen();
    } else if (container.webkitRequestFullscreen) {
      container.webkitRequestFullscreen();
    }
  }
});

// Setup timeline scrubber
document.getElementById("videoPreview").addEventListener("loadedmetadata", setupTimelineScrubber);

function initParticles() {
  const canvas = document.getElementById("particles");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  let stars = [];

  function resize() {
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    stars = Array.from({ length: Math.max(28, Math.floor(window.innerWidth / 40)) }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      s: 0.6 + Math.random() * 1.6,
      a: 0.2 + Math.random() * 0.5,
      t: Math.random() * Math.PI * 2
    }));
  }

  function draw() {
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    for (const p of stars) {
      p.t += 0.02;
      const alpha = p.a + Math.sin(p.t) * 0.14;
      ctx.beginPath();
      ctx.fillStyle = `rgba(106, 212, 255, ${Math.max(0.1, alpha)})`;
      ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
      ctx.fill();
    }
    requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener("resize", resize);
  draw();
}

initParticles();
