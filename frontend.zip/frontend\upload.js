let selectedFile = null;
const dropzone = document.getElementById("dropzone");
const input = document.getElementById("videoInput");
const browseBtn = document.getElementById("browseBtn");
const analyzeBtn = document.getElementById("analyzeBtn");
const statusEl = document.getElementById("status");
const allowed = ["mp4", "avi", "mov"];

function setStatus(msg) {
  statusEl.textContent = msg;
}

function validateFile(file) {
  if (!file || !file.name.includes(".")) return false;
  const ext = file.name.split(".").pop().toLowerCase();
  return allowed.includes(ext);
}

function setFile(file) {
  if (!validateFile(file)) {
    selectedFile = null;
    analyzeBtn.disabled = true;
    setStatus("Invalid format. Please upload MP4, AVI, or MOV.");
    return;
  }
  selectedFile = file;
  analyzeBtn.disabled = false;
  setStatus(`Selected: ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB)`);
}

dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("dragover");
});

dropzone.addEventListener("dragleave", () => {
  dropzone.classList.remove("dragover");
});

dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  setFile(e.dataTransfer.files[0]);
});

browseBtn.addEventListener("click", () => input.click());
input.addEventListener("change", (e) => setFile(e.target.files[0]));

analyzeBtn.addEventListener("click", async () => {
  if (!selectedFile) return;
  analyzeBtn.disabled = true;
  setStatus("Uploading video securely...");

  try {
    const data = new FormData();
    data.append("video", selectedFile);
    const uploadRes = await fetch("/api/upload", { method: "POST", body: data });
    const uploadJson = await uploadRes.json();
    if (!uploadRes.ok) throw new Error(uploadJson.error || "Upload failed");

    setStatus("Running captioning, forensic AI detection, and shot event extraction...");
    const analyzeRes = await fetch(`/api/analyze/${uploadJson.video_id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ runtime_path: uploadJson.runtime_path })
    });
    const analyzeJson = await analyzeRes.json();
    if (!analyzeRes.ok) throw new Error(analyzeJson.error || "Analysis failed");

    localStorage.setItem(
      "analysisResult",
      JSON.stringify({
        fileName: selectedFile.name,
        fileSize: selectedFile.size,
        videoUrl: URL.createObjectURL(selectedFile),
        result: analyzeJson,
        sha256: uploadJson.sha256,
        analyzedAt: new Date().toISOString()
      })
    );
    window.location.href = "/dashboard";
  } catch (err) {
    setStatus(`Error: ${err.message}`);
    analyzeBtn.disabled = false;
  }
});

function initParticles() {
  const canvas = document.getElementById("particles");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  let particles = [];

  function resize() {
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    particles = Array.from({ length: Math.max(24, Math.floor(window.innerWidth / 45)) }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      r: 0.7 + Math.random() * 2.2,
      v: 0.15 + Math.random() * 0.5
    }));
  }

  function tick() {
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    for (const p of particles) {
      p.y -= p.v;
      if (p.y < -8) {
        p.y = window.innerHeight + 8;
        p.x = Math.random() * window.innerWidth;
      }
      ctx.beginPath();
      ctx.fillStyle = "rgba(120, 214, 255, 0.35)";
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    requestAnimationFrame(tick);
  }

  resize();
  window.addEventListener("resize", resize);
  tick();
}

initParticles();
